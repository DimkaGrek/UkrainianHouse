package com.ukraininahouse.ukrainianhouse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UkrainianHouseApplication {

	public static void main(String[] args) {
		SpringApplication.run(UkrainianHouseApplication.class, args);
	}

}
